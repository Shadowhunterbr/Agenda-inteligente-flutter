package com.example.agendainteligente

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
